from data import db_session
from data.jobs import Jobs
from flask import Flask, render_template
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    db_sess = db_session.create_session()
    jobs = Jobs()
    jobs.team_leader = 1
    jobs.job = 'deployment of residential modules 1 and 2'
    jobs.work_size = 15
    jobs.collaborators = '2, 3'
    jobs.is_finished = False
    db_sess.add(jobs)
    db_sess.commit()
    app.run(port=8080, host='127.0.0.1')


@app.route("/gch")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template("f.html", jobs=jobs)


if __name__ == '__main__':
    main()
